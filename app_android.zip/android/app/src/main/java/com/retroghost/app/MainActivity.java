package com.retroghost.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
